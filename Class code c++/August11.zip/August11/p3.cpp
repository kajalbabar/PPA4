//In classes everything by default is private

#include <iostream>

class A{

	int a ;


}; 


class B : A {
	

}; 


int main() {

	B b;
	b.a = 10;
	

}
