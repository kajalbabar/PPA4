
import java.io.*;

class Array7{

   public static void main(String[]args)throws IOException{

	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

	System.out.print("Enter size : " );
	int a=Integer.parseInt(br.readLine());

	int arr[]=new int[a];
	int cnt=0;
	int b=0;

	System.out.println("enter element : ");
	for(int i=0;i<a;i++){
		arr[i]=Integer.parseInt(br.readLine());
	}

	System.out.println("enter element to search: ");
	int num=Integer.parseInt(br.readLine());
		for(int i=0;i<arr.length;i++){
 
			if(arr[i]==num){
				cnt++;
			}
		}				
	System.out.println("no. of "+ num + " is :"+ cnt);
   }
}

/*

s@S:~/Array$ java Array7
Enter size : 6
enter element : 
6
2
3
4
2
4
enter element to search: 
4
no. of 4 is :2

*/
