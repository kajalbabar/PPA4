//default constructor is by default public

#include <iostream>


//empty class 
class Employee {

	//complier will add the constructor after checking the syntax  


};


int main() {
	
	Employee emp;	//implicit call to the constructor
	return 0;

}

