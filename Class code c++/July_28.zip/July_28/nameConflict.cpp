#include <iostream>


void run();

int main(){

	int a = 10;

	//here cin works as a normal varible
	int cin = 20;
	
	std::cout << a << std::endl;
	std::cout << cin << std::endl;
	run();
	return 0;

}

void run() {
	int cout;
	
	//here cout works as a normal varible
	std::cin >> cout;
	std::cout << "Cout = "<< cout << std::endl;
	
}
