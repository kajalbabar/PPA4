#include <iostream>

//void run();

int main() {

	run();
	return 0;

}

