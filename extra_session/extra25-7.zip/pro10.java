
import java.io.*;

class Array10{

	   public static void main(String[]args)throws IOException{

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	
		System.out.print("Enter size : " );
		int a=Integer.parseInt(br.readLine());
	
		int arr[]=new int[a];
		
		int num=0,num1=1,sum=0;

		for(int i=0;i<a;i++){

			
			arr[i]=num;

			sum=num+num1;
			num=num1;
			num1=sum;
		}		
		System.out.println("Fibonacci Series is : ");
		
		for(int i=0;i<a;i++){

			System.out.print( arr[i] +"  ");
		
		}
	 }
}

/*
s@S:~/Array$ javac pro10.java
s@S:~/Array$ java Array10
Enter size : 6
Fibonacci Series is : 
0  1  1  2  3  5
*/
