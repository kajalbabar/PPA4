
import java.io.*;

class Array9{

	   public static void main(String[]args)throws IOException{

		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	
		System.out.print("Enter size : " );
		int a=Integer.parseInt(br.readLine());
	
		int arr[]=new int[a];
		
		int fct=1;

		for(int i=0;i<a;i++){
			arr[i]=(i+1);

		}		
			for(int i=0;i<a;i++){

				fct=fct*arr[i];

				System.out.print(fct +"  ");
			}

	  }
}

/*

s@S:~/Array$ gedit pro9.java
s@S:~/Array$ javac pro9.java
s@S:~/Array$ java Array9
Enter size : 5
1  2  6  24  120 
*/
