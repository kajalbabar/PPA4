//inline

#include <iostream>
void fun() {
	
	
	std :: cout<<"hello ";	
	std :: cout<<"hello ";	
}


int main(){
	fun();
	fun();
	fun();
	fun();
	fun();
//	for(int i= 0; i< 100000 ; i++)
//		fun();
} 
