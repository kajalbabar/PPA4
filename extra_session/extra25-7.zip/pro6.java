
import java.io.*;

class Array6{

   public static void main(String[]args)throws IOException{

	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

	System.out.print("Enter size : " );
	int a=Integer.parseInt(br.readLine());

	int arr[]=new int[a];
	
	int temp=0;
	for(int i=0;i<a;i++){
		arr[i]=Integer.parseInt(br.readLine());
	}
		
		temp=arr[0];		
		arr[0]=arr[a-1];
		arr[a-1]=temp;
		for(int j=0;j<arr.length;j++){
		
		System.out.print(arr[j] + " ");
		}
   }
}

/*
s@S:~/Array$ java Array6
Enter size : 4
1
2
3
4
4 2 3 1

*/
