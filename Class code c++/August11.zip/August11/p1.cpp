//make function `inline

#include <iostream>


//inline function
inline void fun(){
		
		std::cout << "Hello world" << std::endl;
}	



int main() {
	
	//fun calls
	fun();
	fun();
	fun();
	fun();
	fun();
	fun();
}
