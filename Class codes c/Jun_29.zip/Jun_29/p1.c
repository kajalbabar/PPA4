//size of FILE structure

#include<stdio.h>

void main(){
	
	printf("Size of FILE pointer: %d\n",sizeof(FILE));
}
